from Shape import Shape


class Line(Shape):
    
    def __init__(self, p1, p2):
        super().__init__(p1, p2) 
